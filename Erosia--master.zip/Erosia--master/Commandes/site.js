const Discord = require('discord.js')

module.exports.run = (client, message, args) => {

  message.channel.send("Notre site est accessible depuis https://erosia.fr/");

};

module.exports.help = {
  name: 'site'
};
