const Discord = require('discord.js')

module.exports.run = (client, message, args) => {
 
     // Closing the ticket.
        if(userTickets.has(message.author.id)) { // Check if the user has a ticket by checking if the map has their ID as a key.
            if(message.channel.id === userTickets.get(message.author.id)) {
                message.channel.delete('closing ticket') // Delete the ticket.
                .then(channel => {
                    console.log("Deleted " + channel.name);
                    userTickets.delete(message.author.id);
                })
                .catch(err => console.log(err));
            }
        }


module.exports.help = {
name: 'closeticket'
}
