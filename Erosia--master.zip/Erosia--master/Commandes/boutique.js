const Discord = require('discord.js')

module.exports.run = (client, message, args) => {

  message.channel.send("Notre boutique est accessible via https://erosia.fr/site/shop");

};

module.exports.help = {
  name: 'boutique'
};
