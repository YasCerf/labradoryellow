const Discord = require('discord.js');
const RichEmbed = require('discord.js')

module.exports.run = (client, message, args) => {

  let StaffEmbed = new Discord.RichEmbed()
.setTitle(":snowflake:  Staff Erosia !")
.addField(`\n
  :snowflake:  DarrenBray : Gérant du serveur\n

  :snowflake: Administrateur : Tristan | XECA\n

  :snowflake: Organisateur : GhostNever\n

  :snowflake: Formateur : YasCerf\n`, "\n:eject: Partie principale :eject:")

  .addField(`\n


    :snowflake: Surveillant : Lulukiller11 | Marius | AlexMusic | Lesurviants\n

    :snowflake:  Apprentis : luzord | Maximus3333 | Lynaria meeve | ZaYn0TrotinetteDidi | Ethenaay\n

    :snowflake:  Builder: | Naradox | satsuki | MasterFable10E`, ":eject: Partie Secondaire :eject:")


  message.channel.send(StaffEmbed)
};

module.exports.help = {
    name: 'staff'

};
