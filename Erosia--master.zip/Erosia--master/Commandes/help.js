const Discord = require('discord.js')

module.exports.run = (client, message, args) => {

let HelpEmbed = new Discord.RichEmbed()
.setTitle("Voici la liste des commandes !")
.setColor("#333975")
.addField(`/staff : affiche la liste du staff\n

  /boutique et /shop : Lien vers la boutique officiel\n

  /site : Lien vers le site officiel\n

/ping : Vous donne votre ping selon l'api Discord\n

/help : affiche la liste des commandes\n`, "Erosia V1");

message.channel.send(HelpEmbed)

};

module.exports.help = {
  name: 'help'
};
