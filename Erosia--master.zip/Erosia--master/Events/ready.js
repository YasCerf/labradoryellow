module.exports = (client) => {
    client.user.setPresence({
        game: {
            name: "Erosia en préparation !"
        }
    });
};
